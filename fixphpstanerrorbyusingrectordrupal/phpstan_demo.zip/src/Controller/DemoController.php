<?php

namespace Drupal\phpstan_demo\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;

class DemoController extends ControllerBase {

  public function content() {
    $data = $this->getData();

    $value = $data['key']; // possible null issue

    return [
      '#markup' => $value,
    ];
  }

  private function getData() {
    if (rand(0, 1)) {
      return ['key' => 'Hello'];
    }

    return null;
  }

  public function api() {
    $result = $this->process();

    return new JsonResponse($result);
  }

  private function process(): array {
    return "string instead of array";
  }

}
